/**Project 5
 * Suihan Dong
 * dongx460**/

public class BinaryTree<K extends Comparable<K>, V> {
    private Node<K, V> root;

    public BinaryTree(Node root) {

        this.root = root;
    }

    public Node<K, V> getRoot() {

        return this.root;
    }


    /**
     * helper method for find the node with the given key value
     * @param key
     * @return the node with the given key value
     */
    public Node<K, V> findNode(K key) {
        return findHelper(key, root, null);
    }


    /**
     * helper method for add method
     * @param key
     * @param value
     * @param node
     */
    public void addHelper(K key, V value, Node<K, V> node){

        /**if the tree is empty**/
        if(node == null){
            Node<K, V> newRoot = new Node<>(key, value);
            root = newRoot;
        }

        /**if the key already exists**/
        //if the key is at root
        else if(node.getKey().equals(key)){
            node.setValue(value);
        }//end of equal condition

        //pass in key is smaller than the key at root
        else if(node.getKey().compareTo(key) > 0){

            if(node.getLeft() == null){
                Node<K, V> leftRoot = new Node<>(key, value);
                node.setLeft(leftRoot);
            }
            else{
                addHelper(key, value, node.getLeft());
            }
        }//end of smaller condition

        //pass in key is larger than the key at root
        else if( node.getKey().compareTo(key) < 0 ){

            if(node.getRight() == null){
                Node<K,V> rightRoot = new Node<>(key, value);
                node.setRight(rightRoot);
            }
            else{
                addHelper(key, value,node.getRight());
            }
        }//end of larger condition

    }//end of the helper method


    public void add(K key, V value) {
        addHelper(key, value, root);
    }//end of the add method


    /**
     * helper method for find method
     * @param key
     * @param node
     * @param res
     * @return return the value associated with the key passed into the method.If the key does not exist within the binary tree, null should be returned.
     */
    public Node<K, V> findHelper(K key, Node<K, V> node, V res){

        /**if the tree is empty**/
        if(node == null){
            return null;
        }

        /** if the tree is not empty**/
        //if the key is at root
        if(node.getKey().equals(key)){
            return node;
        }
        else{
            //if passed in key is smaller than the key at root
            if(node.getKey().compareTo(key) > 0){
                node = node.getLeft();
                return findHelper(key, node, res);
            }
            //if passed in key is larger than the key at root
            else if (node.getKey().compareTo(key) < 0){
                node = node.getRight();
                return findHelper(key, node, res);
            }
        }//end of the not empty condition
        return null;
    }//end of the helper method


    public V find(K key) {
        V res = null;
        Node<K, V> found = findHelper(key, root, res);
        if (found == null) {
            return null;
        } else {
            return found.getValue();
        }
    }//end of the find method


    //unchecked
    public V[] flatten() {
        if(root == null){
            return (V[]) new Object[0];
        }
        int count = root.getNumberOfNodes();//getNumberOfNodes implement in Node class
        V valueArray[] =  (V[]) new Object[count];
        flattenHelper(root, 0, valueArray);
        return valueArray;

    }//end of the flatten method


    /**
     * helper method for flatten method
     * @param node
     * @param i
     * @param arr
     * @return the position of the array
     */
    public int flattenHelper(Node<K, V> node, int i, V[] arr){
        //first case: the tree is empty
        if(node == null){
            return 0;
        }//end of the 1st case

        int idx = i;

        //second case: has the left following node
        if(node.getLeft() != null){
            idx = flattenHelper(node.getLeft(), idx, arr);
        }
        arr[idx] = node.getValue();
        idx++;

        //third case: has the right following node
        if(node.getRight() != null){
            idx = flattenHelper(node.getRight(), idx, arr);
        }

        return idx;
    }//end of the helper method for flatten



    public void remove(K key) {

        /**find the location of the node**/
        Node<K, V> currentNode = root;
        Node<K, V> previousNode = null;

        //if key is not in the tree
        if(find(key) == null){
            return;
        }

        //find the location of key if it in the tree
        while(currentNode.getKey().compareTo(key) != 0){
            if(currentNode.getKey().compareTo(key) > 0){
                previousNode = currentNode;
                currentNode = currentNode.getLeft();
            }else if(currentNode.getKey().compareTo(key) < 0){
                previousNode = currentNode;
                currentNode = currentNode.getRight();
            }
        }//end of while loop for finding location

        /**if currentNode is not found**/
        if(currentNode == null){
            return;
        }

        /**first case: no following node**/
        if(currentNode.getRight() == null && currentNode.getLeft() == null){

            //key is at root
            if(previousNode == null){
                root = null;
            }

            //key is at left following node
            else if(previousNode.getLeft() == currentNode){
                previousNode.setLeft(null);
            }

            //key is at right following node
            else if(previousNode.getRight() == currentNode){
                previousNode.setRight(null);
            }
        }//end of the 1st case

        /**second case A: only has one following node on left**/
        else if(currentNode.getRight() == null && currentNode.getLeft() != null){
            if(previousNode == null){
                root = currentNode.getLeft();
            }
            else if(previousNode.getLeft() == currentNode){
                previousNode.setLeft(currentNode.getLeft());
            }else if(previousNode.getRight() == currentNode){
                previousNode.setRight(currentNode.getLeft());
            }

        }//end of the 2nd case A

        /**second case B: only has the following node on right**/
        else if(currentNode.getRight() != null && currentNode.getLeft() == null){
            if(previousNode == null){
                root = currentNode.getLeft();
            }
            else if(previousNode.getLeft() == currentNode){
                previousNode.setLeft(currentNode.getRight());
            }else if(previousNode.getRight() == currentNode){
                previousNode.setRight(currentNode.getRight());
            }
        }//end of 2nd case B

        /**third case: have following node on both left and right**/
        else if(currentNode.getRight() != null && currentNode.getLeft() != null){
            Node<K, V> temp = FindLeft(currentNode.getRight(),currentNode);
            remove(temp.getKey());
            Node<K, V> newNode = new Node<>(temp.getKey(), temp.getValue());
            newNode.setLeft(currentNode.getLeft());
            newNode.setRight(currentNode.getRight());

            //remove the root
            if(previousNode == null){
                root = newNode;
            }
            //right node
            else if(currentNode == previousNode.getRight()){
                previousNode.setRight(newNode);
            }
            //left node
            else if(currentNode == previousNode.getLeft()){
                previousNode.setLeft(newNode);
            }
        }//end of 3rd case

    }//end of the remove method


    /**
     * helper method for remove method
     * @param node
     * @param preNode
     * @return the most left node of the removing node
     */
    public Node<K,V> FindLeft(Node<K, V> node, Node<K, V> preNode){

        while(node.getLeft() != null){
            preNode = node;
            node = node.getLeft();
        }
        return node;
    }//end of the helper method



    public boolean containsSubtree(BinaryTree<K, V> other) {
        if (other == null || other.getRoot() == null) {
            return true;
        } else {
            return containsSubtreeHelper(findNode(other.getRoot().getKey()), other.getRoot());
        }
    }//end of the method


    /**
     * helper method for the contianSubtree method
     * @param node1 Origin Node
     * @param node2 Other Node(node in passed in trees
     * @return whether it contains subtree
     */
    public boolean containsSubtreeHelper(Node<K, V> node1, Node<K, V> node2){

        //the tree is empty
        if (node2 == null) {
            return true;
        }
        return node1.getKey().equals(node2.getKey()) && node1.getValue().equals(node2.getValue()) &&
                containsSubtreeHelper(node1.getLeft(), node2.getLeft()) &&
                containsSubtreeHelper(node1.getRight(), node2.getRight());

    }//end of the helper method

}//end of the class
